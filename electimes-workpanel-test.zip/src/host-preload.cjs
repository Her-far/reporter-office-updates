/* Bundled inline into trusted editor preloads. No mail or calendar data enters the editor. */
;(()=>{
  const {ipcRenderer}=require('electron');
  let state=null,open=true,target=null,slot=null,bar=null,frame=0,started=false,starting=false,last='',drag=false;
  const css=`
    :root{--wp-border:var(--border,#d8dde6);--wp-surface:var(--surface,#fff);--wp-text:var(--text,#243049);--wp-accent:var(--accent,#244b7d)}
    .wp-dock{position:relative;flex-direction:column!important;order:10!important;transition:none!important;min-width:0!important;flex-shrink:0!important;background:var(--wp-surface);color:var(--wp-text)}
    .wp-dock:not([data-wp-menu="ai"])>:not(.wp-toolbar):not(.wp-slot):not(.ai-panel-resizer):not(.wp-resize){display:none!important}
    .wp-dock>.ai-panel,.wp-dock>.copilot{flex:1;min-height:0}
    .wp-toolbar{display:flex!important;flex:0 0 42px;min-height:42px;align-items:center;gap:2px;padding:0 6px 0 10px;border-bottom:1px solid var(--wp-border);background:var(--wp-surface);box-sizing:border-box;z-index:20;font-family:inherit}
    .wp-toolbar button{font:inherit;font-size:12px;white-space:nowrap;border:0;border-radius:5px;background:transparent;color:var(--wp-text);padding:7px 8px;cursor:pointer}
    .wp-toolbar button[aria-selected="true"]{background:var(--wp-accent);color:var(--accent-contrast,#fff)}
    .wp-toolbar button:focus-visible,.wp-launch:focus-visible{outline:2px solid var(--wp-accent);outline-offset:1px}
    .wp-toolbar .wp-menu-end{margin-left:auto}
    .wp-slot{flex:1;min-height:80px;display:block}
    [data-wp-menu="ai"]>.wp-slot{display:none}
    .wp-expanded{position:fixed!important;inset:0 0 0 auto!important;height:100vh!important;max-width:100vw!important;z-index:2147482000;border-left:1px solid var(--wp-border)}
    .wp-closed{display:none!important}
    .wp-launch{position:fixed;right:16px;bottom:9px;z-index:2147482001;border:1px solid var(--wp-border);border-radius:7px;background:var(--wp-surface);color:var(--wp-text);padding:5px 9px;font:12px system-ui;cursor:pointer;box-shadow:0 2px 8px #0001}
    .wp-home{position:fixed!important;right:8px;top:50px;bottom:40px;display:flex;border:1px solid var(--wp-border);box-shadow:0 4px 20px #0001;border-radius:7px;z-index:100}
    .wp-resize{position:absolute;left:0;top:0;bottom:0;width:7px;cursor:col-resize;z-index:50;touch-action:none}
    .wp-home-ai{padding:24px;font:14px/1.7 system-ui}
    .wp-dock:not([data-wp-menu="ai"]) .wp-home-ai{display:none}
  `;
  const names={ko:['AI','메일','캘린더','일정','업무 연동','확장 / 복원','닫기','업무 패널'],en:['AI','Mail','Calendar','Agenda','Work settings','Expand / restore','Close','Work panel'],ja:['AI','メール','カレンダー','予定','業務連携','拡大 / 復元','閉じる','業務パネル'],zh:['AI','邮件','日历','日程','工作设置','展开 / 还原','关闭','工作面板'],'zh-TW':['AI','郵件','日曆','行程','工作設定','展開 / 還原','關閉','工作面板'],de:['KI','Mail','Kalender','Termine','Arbeitsoptionen','Erweitern / zurück','Schließen','Arbeitsbereich'],fr:['IA','Mail','Calendrier','Agenda','Réglages','Agrandir / réduire','Fermer','Espace de travail'],es:['IA','Correo','Calendario','Agenda','Ajustes','Ampliar / restaurar','Cerrar','Panel de trabajo'],it:['IA','Posta','Calendario','Agenda','Impostazioni','Espandi / ripristina','Chiudi','Pannello di lavoro'],pt:['IA','Correio','Calendário','Agenda','Configurações','Expandir / restaurar','Fechar','Painel de trabalho'],ru:['ИИ','Почта','Календарь','Планы','Настройки','Развернуть / свернуть','Закрыть','Рабочая панель'],ar:['AI','البريد','التقويم','المواعيد','الإعدادات','توسيع / استعادة','إغلاق','لوحة العمل'],he:['AI','דואר','לוח שנה','יומן','הגדרות','הרחבה / שחזור','סגירה','לוח עבודה'],hi:['AI','मेल','कैलेंडर','कार्यसूची','सेटिंग','विस्तार / बहाल','बंद करें','कार्य पैनल'],vi:['AI','Thư','Lịch','Lịch trình','Cài đặt','Mở rộng / khôi phục','Đóng','Bảng công việc'],th:['AI','อีเมล','ปฏิทิน','กำหนดการ','ตั้งค่า','ขยาย / คืนค่า','ปิด','แผงงาน'],id:['AI','Surat','Kalender','Agenda','Pengaturan','Perluas / pulihkan','Tutup','Panel kerja'],ms:['AI','Mel','Kalendar','Agenda','Tetapan','Kembangkan / pulihkan','Tutup','Panel kerja'],nl:['AI','Mail','Kalender','Agenda','Instellingen','Vergroten / herstellen','Sluiten','Werkpaneel'],pl:['AI','Poczta','Kalendarz','Plan','Ustawienia','Rozwiń / przywróć','Zamknij','Panel pracy'],cs:['AI','Pošta','Kalendář','Program','Nastavení','Rozbalit / obnovit','Zavřít','Pracovní panel']};
  function labels(){const lang=document.documentElement.lang||'ko';return names[lang]||names[lang.split('-')[0]]||names.ko;}
  const action=(action,value)=>ipcRenderer.invoke('wp:host-action',{action,value}).then(s=>{state=s;update();}).catch(()=>{});
  function btn(text,title,handler){const b=document.createElement('button');b.type='button';b.textContent=text;b.title=title;b.setAttribute('aria-label',title);b.addEventListener('mousedown',e=>e.preventDefault());b.onclick=handler;return b;}
  function schedule(){if(frame)return;frame=requestAnimationFrame(()=>{frame=0;update();});}
  function mount(node){target=node;target.classList.add('wp-dock');bar=document.createElement('div');bar.className='wp-toolbar';bar.setAttribute('role','tablist');const l=labels();
    ['ai','mail','calendar','schedule'].forEach((key,i)=>{const b=btn(l[i],l[i],()=>{open=true;void action('menu',key);});b.dataset.menu=key;b.setAttribute('role','tab');bar.append(b);});
    const settings=btn('⚙',l[4],()=>{open=true;void action('menu','settings');});settings.className='wp-menu-end';bar.append(settings);const badge=document.createElement('small');badge.textContent='TEST';badge.style.fontSize='9px';bar.append(badge);
    bar.append(btn('↗',l[5],()=>action('expanded',!state.expanded)),btn('×',l[6],()=>{open=false;void action('closed');update();}));
    slot=document.createElement('div');slot.className='wp-slot';target.prepend(bar);target.append(slot);
    const resize=document.createElement('div');resize.className='wp-resize';resize.role='separator';resize.tabIndex=0;resize.setAttribute('aria-orientation','vertical');resize.setAttribute('aria-label','패널 너비');
    resize.onkeydown=e=>{if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();action('width',state.prefs.width+(e.key==='ArrowLeft'?20:-20));}};
    resize.onpointerdown=e=>{e.preventDefault();e.stopPropagation();drag=true;resize.setPointerCapture(e.pointerId);const move=ev=>{state.prefs.width=Math.max(300,Math.min(innerWidth-240,innerWidth-ev.clientX));update();};const stop=()=>{drag=false;resize.removeEventListener('pointermove',move);resize.removeEventListener('pointerup',stop);resize.removeEventListener('pointercancel',stop);void action('width',state.prefs.width);};resize.addEventListener('pointermove',move);resize.addEventListener('pointerup',stop);resize.addEventListener('pointercancel',stop);};target.append(resize);
    new ResizeObserver(schedule).observe(target);new ResizeObserver(schedule).observe(slot);
  }
  function update(){if(!state||!document.body)return;
    const isHome=!document.querySelector('.ai-dock,aside.ai-panel,aside.copilot');
    let node=document.querySelector('.ai-dock')||document.querySelector('aside.ai-panel,aside.copilot');
    if(!node&&isHome){node=document.getElementById('wp-home');if(!node){node=document.createElement('section');node.id='wp-home';node.className='wp-home';const hint=document.createElement('p');hint.className='wp-home-ai';hint.textContent='문서 탭을 열면 기존 AI 대화와 문서 작성 기능을 이용할 수 있습니다.';node.append(hint);document.body.append(node);}}
    const home=document.getElementById('wp-home');if(home&&home!==node)home.remove();
    if(node&&(node!==target||!bar?.isConnected)){mount(node);}
    if(!target)return;
    if(open&&state.menu==='ai'){const rail=target.querySelector('button.ai-rail,button[data-tip]');if(rail?.classList.contains('ai-rail')&&!rail.dataset.wpExpanding){rail.dataset.wpExpanding='1';rail.click();}}
    target.classList.toggle('wp-closed',!open);target.classList.toggle('wp-expanded',!!state.expanded||innerWidth<740);target.dataset.wpMenu=state.menu;
    const w=(state.expanded||innerWidth<740)?innerWidth:Math.max(300,Math.min(state.prefs.width,innerWidth-320));
    const width=w+'px';if(target.style.getPropertyValue('width')!==width)target.style.setProperty('width',width,'important');
    const body=target.closest('.sheet-body');if(body){body.style.setProperty('grid-template-columns',`minmax(0,1fr) ${open?w:0}px`,'important');target.style.setProperty('order','10','important');}
    document.documentElement.setAttribute('data-ai-panel-side','right');
    bar.querySelectorAll('[data-menu]').forEach(b=>{const val=String(b.dataset.menu===state.menu);if(b.getAttribute('aria-selected')!==val)b.setAttribute('aria-selected',val);});
    let launch=document.getElementById('wp-launch');if(!launch){launch=btn(labels()[7]+' · TEST',labels()[7],()=>{open=!open;update();});launch.id='wp-launch';launch.className='wp-launch';document.body.append(launch);}launch.style.display=open?'none':'';
    const r=slot.getBoundingClientRect();const blocked=!!document.querySelector('[aria-modal="true"],.set-overlay,.modal-backdrop');
    const msg={visible:open&&!blocked&&document.visibilityState!=='hidden'&&state.menu!=='ai',rect:{x:r.x+7,y:r.y,width:Math.max(0,r.width-7),height:r.height}};const s=JSON.stringify(msg);if(s!==last){last=s;ipcRenderer.send('wp:host-layout',msg);}
    const nav=document.querySelector('.set-sidebar,.set-nav');if(nav&&!nav.querySelector('.wp-settings-entry')){const b=btn(labels()[4],labels()[4],()=>{document.querySelector('.set-close')?.click();open=true;action('menu','settings');});b.className='set-nav-item wp-settings-entry';nav.append(b);}
  }
  async function start(){if(started||starting)return;if(!document.body){window.addEventListener('DOMContentLoaded',()=>void start(),{once:true});return;}starting=true;try{state=await ipcRenderer.invoke('wp:host-init');}catch{starting=false;return;}started=true;starting=false;open=state.prefs.showOnStart;const style=document.createElement('style');style.textContent=css;document.head.append(style);new MutationObserver(schedule).observe(document.body,{childList:true,subtree:true});window.addEventListener('resize',schedule);document.addEventListener('visibilitychange',()=>{last='';schedule();});document.addEventListener('pointerdown',()=>{last='';schedule();},true);update();}
  ipcRenderer.on('wp:host-state',(_e,s)=>{state=s;schedule();});ipcRenderer.on('wp:refresh',()=>{last='';if(!started)void start();else schedule();});
  if(document.readyState==='loading')window.addEventListener('DOMContentLoaded',()=>void start(),{once:true});else void start();
})();
