# Test scope — 1.0.4-workpanel.2

13 core automated tests cover hostile file names and URLs, settings validation, event time conversion, all-day end exclusivity, Google desktop client validation, actual local OAuth callback handling with a mock token server, state/PKCE, cancellation, encryption availability, event pagination, offline cache, edit permissions, etag conflicts and disconnect behavior. They do not authenticate a real Google account.

The Linux Electron headless checks exercise the actual 1.0.4 editor payload and newly packaged extension. They enter HWP text, preserve selection and an unsent AI draft across panel changes, check resize/expanded/close behavior, inspect actual remote WebContents security settings, and test a synthetic attachment. The harness uses a test-only singleton-lock override because the Linux environment does not permit Electron's Unix socket; this override is not shipped. These tests are not proof of Windows IME behavior or production-scale performance.

The separate `windows-smoke.json`, when present from a successful Actions run, records real Windows installer, simultaneous startup, distinct profile, official binary and registration preservation, and uninstall checks. Only checks recorded as true in that file are considered passed. Google/NAVER account login and live data remain unverified regardless of the build result.

| Scenario | Status / boundary |
| --- | --- |
| Existing editor engine resources | Byte-for-byte preservation verified by BUILD-VERIFICATION.json |
| Core security, OAuth and Calendar logic | 13 automated tests passed |
| HWP text and selection / AI draft | Actual Linux Electron renderer checked |
| Mail external content isolation | Actual remote WebContents preferences checked |
| Attachment download and new-tab copy | Synthetic attachment test; live mail attachments require user verification |
| Calendar month/events | Synthetic event UI and mocked API checks; real account data unverified |
| Calendar write / delete | Permission, etag and payload tests; actual Google mutation unverified |
| Native Windows install / simultaneous startup / uninstall | See the separate Windows result; do not infer success from Linux |
| NAVER login, SSO, 2FA, session persistence | User account test required |
| Google real OAuth / organization policy | Developer-registered desktop client absent; account flow unverified |
| All file formats and image preview | Existing routes retained; individual live documents not exhaustively tested |
| Memory, long sessions, large Sheets files, IME | Quantitative Windows validation required |

Known limits: new panel content is Korean; toolbar labels follow existing languages. Images open in a separate preview window. Unsupported/custom SSO domains go to an external browser after confirmation. Mail views are retained while hidden to preserve drafts; throttling cannot guarantee zero background CPU. No persisted offline calendar cache, attendees editing, recurrence rule editing, conflict merging, or AI auto-summary is included. The program is unsigned.

Revision 2 adds home split layout (1024/1330/1918 px), full-width restoration on close, clearer separator, explicit mail login/inbox controls and developer OAuth build injection. Linux headless cannot validate the new native login window: native window creation crashes in that environment (also a minimal independent probe), so login-window interaction is explicitly unverified; the remaining UI checks run without opening it. No user credentials were entered.
