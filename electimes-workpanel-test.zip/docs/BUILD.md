# Reproducible isolated test build

This extension is based on the real `ElectimesOffice-Source-1.0.4.zip` project. The original project uses Electron, React, TypeScript, native WebContentsView document tabs, and multiple editor engines. The monorepo retains HWP, DOCX, Sheets, Slides, PDF, Markdown, HTML and other modules. AI belongs to each editor renderer. Existing tab and document APIs remain in use.

The supplied upstream source snapshot includes earlier 0.12.5.35 source plus the later 1.0.4 distribution modifications. This test build therefore assembles an additive, audited extension over the verified 1.0.4 compiled payload; it is not presented as a fresh rebuild of every original editor engine. Original editor renderer bundles, fonts, WASM, native helpers and licenses are byte-compared. The source for every new behavior is in `src/`. The exact shell integration, profile isolation and updater replacement are reproducible in `build/build.cjs`, with fail-closed single-match anchors. It rejects mismatched package identity and an existing output folder.

## Windows prerequisites and commands

Use Node 22+, Python 3, 7-Zip and NSIS. Run in a new local folder; never use the production install folder. Install the build-only resource editor with `npm install --no-save --ignore-scripts resedit@3.1.1` in this extension's directory. No account credentials are needed to build.

```powershell
node --test tests/core.test.cjs
./build/build-windows.ps1
```

The script downloads the existing official installer only as input, verifies SHA-256, extracts it, builds a separate payload, brands the new EXE, generates an exact uninstall manifest, and compiles `dist/ElectimesOffice-WorkPanel-Test-Setup.exe`. It never publishes a release or modifies the official JSON feed. A predownloaded installer can be supplied using `-BaseArchive`.

Pinned input: ElectimesOffice-Setup-1.0.4-x64.exe

SHA-256: `889b72d7d47d9ce9a1c3a25868b6f121e1b61d794cf2dab9bcc67cda0608843e`

GitHub test workflow: `build/workpanel-test.yml`. Copy it to `.github/workflows/workpanel-test.yml` only on `test/electimes-workpanel-20261116`; place a ZIP of this extension's contents at repository root as `electimes-workpanel-test.zip`. It uses `contents: read`, has no release/commit/push step, and only uploads Actions artifacts. Do not modify or dispatch the existing production distribution workflow. No PR merge into main is part of this task.

## Identity and boundaries

| Item | Test value |
| --- | --- |
| App ID | kr.co.electimes.office.workpanel.test |
| Package | electimes-office-workpanel-test |
| Version | 1.0.4-workpanel.2 |
| EXE | ElectimesOffice-WorkPanel-Test.exe |
| Default installation | %LOCALAPPDATA%\Programs\ElectimesOffice-WorkPanel-Test |
| Profile | %APPDATA%\ElectimesOffice-WorkPanel-Test |
| Mail partition | persist:electimes-workpanel-test-mail |
| Uninstall registry key | HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\ElectimesOffice-WorkPanel-Test |
| Update provider | Disabled handlers; production feed removed |

No default file-association registration is performed. The test app keeps its own single-instance lock because its userData path differs. Uninstall deletes only shipped files using a generated manifest; it does not recursively erase profiles or user documents.

## Architecture

`host-preload.cjs` adds controls and geometry to trusted existing editor preloads. It never receives calendar events, tokens, or mail content. It retains the existing AI React subtree and HWP iframe. `main.cjs` places the independent local panel WebContentsView above its slot and a second isolated WebContentsView for NAVER WORKS. No remote preload, Node integration, or permissive certificate handler is installed. IPC authenticates sender identity and main frame. External links require an explicit user action/confirmation.

`oauth.cjs` implements system-browser OAuth with PKCE, state and a loopback receiver. `vault.cjs` rejects unavailable encryption, protects desktop client configuration/refresh tokens with safeStorage, and never falls back to plaintext. `calendar.cjs` handles pagination, selected calendars, offline in-memory cache, conditional edits and revocation. The panel uses a restrictive local CSP and text nodes for remote content.

Original licenses and NOTICE are retained. This is an independent experimental derivative; no claim of endorsement by upstream authors, NAVER or Google is made.

## Developer-preconfigured Google connection

Set `WORKPANEL_GOOGLE_OAUTH_FILE` to a private Desktop OAuth JSON file outside this repository before running `build-windows.ps1`. Assembly validates the installed-client format and includes only client_id/client_secret in a main-process-only app resource. It never prints their values or sends them through IPC. Users then see **구글 계정 연결** without JSON import. Existing encrypted user configuration takes precedence, preserving old connections. A desktop client is public-client configuration, not a confidential server secret; never use a web/server client here. Refresh tokens are separately protected with OS encryption.

No actual Google registration was available for the supplied revision. The build report explicitly records `googleOAuthPreconfigured: false`. The Google Cloud console returned Site Unavailable in the development browser; no project/API/consent/client creation was performed. Do not claim Google account connection works until a real registered client is supplied and the account flow is verified.

Developer prerequisites: enable Google Calendar API, configure consent/audience and test users if needed, register Desktop app client, and store the JSON outside Git. For CI, supply a protected build secret to a temporary file and delete it after build; never commit credentials into the source ZIP. Ordinary users should not perform these steps. The default public CI build intentionally has no client credentials.

References: https://developers.google.com/identity/protocols/oauth2/native-app ; https://developers.worksmobile.com/kr/docs/sso-sp
