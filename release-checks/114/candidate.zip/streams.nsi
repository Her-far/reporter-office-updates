Unicode true
Name "Electimes update packaging"
OutFile "newblocks.exe"
SetCompressor zlib
Section
SetOutPath "$TEMP"
File 114-asar.raw
File 114-cli.raw
SectionEnd
